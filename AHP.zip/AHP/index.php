<?php
session_start();

if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit;
}

include 'koneksi.php';

$jenis = trim((string)@$_POST['jenis'] ?? '');
$biaya = trim((string)@$_POST['biaya'] ?? '');
$teknis = trim((string)@$_POST['teknis'] ?? '');
$dampak = trim((string)@$_POST['dampak'] ?? '');

if($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($jenis) && !empty($biaya) && !empty($teknis) && !empty($dampak)) {
        $jumlah_biaya = $biaya * 0.540;
        $jumlah_teknis = $teknis * 0.300;
        $jumlah_dampak = $dampak * 0.160;
        $bobot_akhir = $jumlah_biaya + $jumlah_teknis + $jumlah_dampak;

        $sql = "INSERT INTO perhitungan (jenis, k1, k2, k3, hasil) 
        VALUES ('$jenis', $biaya , $teknis, $dampak, $bobot_akhir)";
        $result = mysqli_query($conn, $sql);

        echo "<script>alert('Data berhasil disimpan!'); window.location.href='index.php';</script>";    
    } else {
        echo "<script>alert('Semua field harus diisi!'); window.location.href='index.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Perhitungan AHP Digital Marketing</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { height: 100%; }
body {
    font-family: 'Inter', sans-serif;
    background: #F1F3F6;
    color: #1F2937;
    line-height: 1.5;
}
:root {
    --bg: #F1F3F6;
    --surface: #FFFFFF;
    --border: #E3E6EB;
    --border-strong: #D3D7DE;
    --text-primary: #1F2937;
    --text-secondary: #5B6472;
    --text-muted: #9AA1AC;
    --accent: #3D5A80;
    --accent-hover: #32496A;
    --accent-soft: #E8EEF4;
    --success: #2F7D5C;
    --success-soft: #E4F3EC;
    --danger: #B3413A;
    --danger-soft: #FBEAE8;
    --radius-lg: 14px;
    --radius-md: 10px;
    --radius-sm: 8px;
}

.container { display: flex; min-height: 100vh; }

/* ===== Sidebar kiri ===== */
.kiri {
    width: 240px;
    flex-shrink: 0;
    background: var(--surface);
    border-right: 1px solid var(--border);
    padding: 28px 20px;
    display: flex;
    flex-direction: column;
    gap: 16px;
}
.headKir span {
    font-weight: 700;
    font-size: 1.05rem;
    position: relative;
    padding-left: 16px;
}
.headKir span::before {
    content: '';
    position: absolute;
    left: 0; top: 50%;
    transform: translateY(-50%);
    width: 7px; height: 7px;
    border-radius: 50%;
    background: var(--accent);
}
.kiri hr { border: none; border-top: 1px solid var(--border); }
.kiri ul { list-style: none; display: flex; flex-direction: column; gap: 3px; flex: 1; }
.kiri li {
    padding: 10px 14px;
    border-radius: var(--radius-sm);
    font-size: .9rem;
    font-weight: 500;
    color: var(--text-secondary);
    cursor: pointer;
    border-left: 2px solid transparent;
    transition: all .15s ease;
}
.kiri li:hover { background: var(--accent-soft); color: var(--accent); }
.kiri li.active {
    background: var(--accent-soft);
    color: var(--accent);
    border-left-color: var(--accent);
    font-weight: 600;
}
.logout-item { margin-top: auto; border-top: 1px solid var(--border); padding-top: 12px; }
.logout-item li { color: var(--danger); }
.logout-item li:hover { background: var(--danger-soft); border-left-color: var(--danger); }

/* ===== Konten tengah ===== */
.tengah {
    flex: 1;
    min-width: 0;
    padding: 32px 32px 40px;
    position: relative;
}
.tengah > header {
    font-weight: 700;
    font-size: 1.3rem;
    padding-bottom: 16px;
    margin-bottom: 24px;
    padding-right: 170px;
    border-bottom: 1px solid var(--border);
}
.adminBar {
    position: absolute;
    top: 32px;
    right: 32px;
    display: flex;
    align-items: center;
    gap: 10px;
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 6px 16px 6px 6px;
    border-radius: 999px;
}
.adminBar span:first-child {
    width: 28px; height: 28px;
    border-radius: 50%;
    background: var(--accent);
    color: #fff;
    font-weight: 700;
    font-size: .78rem;
    display: flex; align-items: center; justify-content: center;
}
.adminBar span:last-child { font-size: .84rem; font-weight: 600; color: var(--text-secondary); }

.card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 22px 26px;
    box-shadow: 0 1px 2px rgba(16,24,40,.04);
    margin-bottom: 22px;
}
.card .label {
    font-size: .74rem;
    font-weight: 600;
    letter-spacing: .08em;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 14px;
}
.titleT { font-weight: 700; font-size: .98rem; display: block; margin-bottom: 12px; }

/* Ringkasan bobot kriteria */
.kriteria-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
}
.kriteria-item {
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    padding: 14px 16px;
}
.kriteria-item .kode {
    font-family: 'IBM Plex Mono', monospace;
    font-size: .7rem;
    color: var(--accent);
    font-weight: 600;
}
.kriteria-item .nama {
    font-size: .86rem;
    font-weight: 600;
    color: var(--text-primary);
    margin: 4px 0 8px;
}
.kriteria-item .bobot {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 1.3rem;
    font-weight: 700;
    color: var(--text-primary);
}

/* Tabel + footer total (nempel jadi satu blok) */
.table-wrap {
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    overflow: hidden;
}
.table-wrap table {
    border: none;
    border-radius: 0;
}
table { width: 100%; border-collapse: separate; border-spacing: 0; border-radius: var(--radius-md); border: 1px solid var(--border); overflow: hidden; }
th {
    font-size: .7rem; font-weight: 600; letter-spacing: .06em; text-transform: uppercase;
    color: var(--text-muted); background: #FAFBFC; text-align: left;
    padding: 12px 16px; border-bottom: 1px solid var(--border);
}
td { padding: 11px 16px; font-size: .87rem; color: var(--text-secondary); border-bottom: 1px solid var(--border); }
td.mono { font-family: 'IBM Plex Mono', monospace; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: #FAFBFC; }

.total-footer {
    display: flex;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: #FAFBFC;
    margin-bottom: 14px;
}
.total-item {
    flex: 1;
    padding: 12px 16px;
    border-right: 1px solid var(--border);
}
.total-item:last-child { border-right: none; }
.total-label {
    display: block;
    font-size: .68rem;
    font-weight: 600;
    letter-spacing: .06em;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 4px;
}
.total-value {
    display: block;
    font-family: 'IBM Plex Mono', monospace;
    font-size: .92rem;
    font-weight: 700;
    color: var(--text-primary);
}
.total-item-highlight .total-value { color: var(--accent); }

.total-single {
    text-align: center;
    padding: 18px 16px;
    border: 1px solid var(--border);
    border-radius: var(--radius-md);
    background: #FAFBFC;
}
.total-single .total-label {
    display: block;
    font-size: .72rem;
    font-weight: 600;
    letter-spacing: .06em;
    text-transform: uppercase;
    color: var(--text-muted);
    margin-bottom: 8px;
}
.total-single .total-value {
    display: block;
    font-family: 'IBM Plex Mono', monospace;
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--accent);
}

.badge {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 3px 11px; border-radius: 999px; font-size: .72rem; font-weight: 600;
}
.badge::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
.badge-lolos { background: var(--success-soft); color: var(--success); }
.badge-gugur { background: var(--danger-soft); color: var(--danger); }

.btn-delete, .btn-edit {
    padding: 4px 12px; border-radius: var(--radius-sm); font-size: .75rem; font-weight: 600; cursor: pointer;
}
.btn-delete { border: none; background: var(--danger-soft); color: var(--danger); }
.btn-delete:hover { background: var(--danger); color: #fff; }
.btn-edit { border: 1px solid var(--border-strong); background: var(--surface); color: var(--text-secondary); }
.btn-edit:hover { border-color: var(--accent); color: var(--accent); }

/* ===== Panel form kanan ===== */
.kanan {
    width: 300px;
    flex-shrink: 0;
    border-left: 1px solid var(--border);
    background: var(--surface);
    padding: 28px 24px;
}
.kanan-sticky { position: sticky; top: 28px; }
.kanan .label {
    font-size: .74rem; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
    color: var(--text-muted); margin-bottom: 4px;
}
.kanan .sublabel {
    font-size: .78rem; color: var(--text-secondary); margin-bottom: 20px;
}
.form-group { margin-bottom: 16px; }
.form-group .criteria-code {
    font-family: 'IBM Plex Mono', monospace;
    font-size: .68rem;
    color: var(--accent);
    font-weight: 600;
    letter-spacing: .04em;
}
.form-group label {
    display: block;
    font-size: .82rem;
    font-weight: 600;
    color: var(--text-primary);
    margin: 3px 0 6px;
}
.form-group input, .form-group select {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    font-size: .88rem;
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    transition: all .15s ease;
}
.form-group input:focus, .form-group select:focus {
    outline: none;
    border-color: var(--accent);
    background: var(--surface);
    box-shadow: 0 0 0 3px rgba(61,90,128,.12);
}
.form-hint { font-size: .72rem; color: var(--text-muted); margin-top: 5px; }

.btn-submit {
    width: 100%;
    padding: 11px 18px;
    background: var(--accent);
    color: #fff;
    border: none;
    border-radius: var(--radius-sm);
    font-weight: 600;
    font-size: .88rem;
    cursor: pointer;
    margin-top: 6px;
    transition: background .15s ease;
}
.btn-submit:hover { background: var(--accent-hover); }

@media (max-width: 1000px) {
    .container { flex-direction: column; }
    .kiri { width: 100%; flex-direction: row; align-items: center; justify-content: space-between; padding: 14px 20px; }
    .kiri hr { display: none; }
    .kiri ul { flex-direction: row; }
    .logout-item { margin-top: 0; border-top: none; padding-top: 0; }
    .tengah { padding: 84px 20px 40px; }
    .tengah > header { padding-right: 0; }
    .adminBar { top: 14px; right: 20px; }
    .kanan { width: 100%; border-left: none; border-top: 1px solid var(--border); }
    .kanan-sticky { position: static; }
    .kriteria-grid { grid-template-columns: 1fr; }
    .total-footer { flex-wrap: wrap; }
    .total-item { flex: 1 1 50%; border-bottom: 1px solid var(--border); }
}
</style>
</head>
<body>
<div class="container">

    <!-- KIRI: sidebar -->
    <div class="kiri">
        <div class="headKir"><span>Admin</span></div>
        <hr>
        <ul>
            <li class="active">Perhitungan AHP</li>
        </ul>
        <div class="logout-item">
            <li onclick="window.location.href='?logout=1'">🚪 Logout</li>
        </div>
    </div>

    <!-- TENGAH: konten -->
    <div class="tengah">
        <header>Perhitungan AHP Digital Marketing</header>
        <div class="adminBar">
            <span>A</span>
            <span>Admin</span>
        </div>

        <!-- Ringkasan bobot kriteria -->
        <div class="card">
            <div class="label">Bobot Kriteria</div>
            <div class="kriteria-grid">
                <div class="kriteria-item">
                    <div class="kode">K1</div>
                    <div class="nama">Biaya</div>
                    <div class="bobot">0.540</div>
                </div>
                <div class="kriteria-item">
                    <div class="kode">K2</div>
                    <div class="nama">Teknis</div>
                    <div class="bobot">0.300</div>
                </div>
                <div class="kriteria-item">
                    <div class="kode">K3</div>
                    <div class="nama">Dampak</div>
                    <div class="bobot">0.160</div>
                </div>
            </div>
        </div>

        <!-- Total keseluruhan -->
        <div class="card">
            <div class="label">Total Keseluruhan</div>
            <?php
            $sql_total = "SELECT SUM(k1) AS total_biaya, SUM(k2) AS total_teknis,
                                 SUM(k3) AS total_dampak, SUM(hasil) AS total_hasil
                          FROM perhitungan";
            $result_total = mysqli_query($conn, $sql_total);
            $row_total = mysqli_fetch_assoc($result_total);
            ?>
            <div class="total-footer">
                <div class="total-item">
                    <span class="total-label">Total Biaya</span>
                    <span class="total-value"><?php echo $row_total['total_biaya']; ?></span>
                </div>
                <div class="total-item">
                    <span class="total-label">Total Teknis</span>
                    <span class="total-value"><?php echo $row_total['total_teknis']; ?></span>
                </div>
                <div class="total-item">
                    <span class="total-label">Total Dampak</span>
                    <span class="total-value"><?php echo $row_total['total_dampak']; ?></span>
                </div>
                <div class="total-item total-item-highlight">
                    <span class="total-label">Total Bobot</span>
                    <span class="total-value"><?php echo number_format($row_total['total_hasil'], 3); ?></span>
                </div>
            </div>

            
        </div>

        <!-- Tabel hasil -->
        <div class="card">
            <span class="titleT">Hasil Perhitungan AHP</span>

            <div class="table-wrap">
                <table>
                    <tr>
                        <th>Jenis Digital Marketing</th>
                        <th>Biaya</th>
                        <th>Teknis</th>
                        <th>Dampak</th>
                        <th>Bobot Akhir</th>
                    </tr>
                    <?php
                    $sql = "SELECT * FROM perhitungan ORDER BY hasil DESC";
                    $result = mysqli_query($conn, $sql);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['jenis'] . "</td>";
                        echo "<td class='mono'>" . $row['k1'] . "</td>";
                        echo "<td class='mono'>" . $row['k2'] . "</td>";
                        echo "<td class='mono'>" . $row['k3'] . "</td>";
                        echo "<td class='mono'>" . $row['hasil'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </table>
            </div>
        </div>
    </div>

    <!-- KANAN: form input -->
    <div class="kanan">
        <div class="kanan-sticky">
            <div class="label">Tambah Data</div>
            <div class="sublabel">Isi penilaian per kriteria</div>

            <form method="POST" action="#">
                <div class="form-group">
                    <label>Jenis Digital Marketing</label>
                    <select name="jenis" id="jenis">
                        <option value="">— Pilih jenis —</option>
                        <option>Social Media Marketing</option>
                        <option>Content Marketing</option>
                        <option>Affiliate Marketing</option>
                        <option>Search Engine Optimization (SEO)</option>
                        <option>Mobile Marketing (WA/SMS)</option>
                        <option>Pay-Per-Click Advertising (PPC)</option>
                        <option>Search Engine Marketing (SEM)</option>
                        <option>Email Marketing</option>
                    </select>
                </div>

                <div class="form-group">
                    <span class="criteria-code">K1</span>
                    <label>Biaya</label>
                    <input type="text" placeholder="Masukan Nilai" name="biaya">
                </div>

                <div class="form-group">
                    <span class="criteria-code">K2</span>
                    <label>Teknis</label>
                    <input type="text"  placeholder="Masukan Nilai" name="teknis">
                </div>

                <div class="form-group">
                    <span class="criteria-code">K3</span>
                    <label>Dampak</label>
                    <input type="text" placeholder="Masukan Nilai" name="dampak">
                </div>

                <button type="submit" class="btn-submit">Simpan Data</button>
            </form>
        </div>
    </div>

</div>
</body>
</html>