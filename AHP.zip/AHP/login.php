<?php
session_start();

// Kalau udah login, langsung lempar ke halaman admin
if (isset($_SESSION['admin_login']) && $_SESSION['admin_login'] === true) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = trim((string)($_POST['password'] ?? ''));

    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['admin_login'] = true;
        $_SESSION['admin_username'] = $username;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Username atau password salah!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        background-color: #fff;
        padding: 30px;
        width: 20%;
        min-width: 280px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    label {
        margin-top: 10px;
    }

    input {
        padding: 8px;
        margin-top: 5px;
    }

    button {
        margin-top: 15px;
        padding: 10px;
        background-color: #3D5A80;
        color: white;
        border: none;
        cursor: pointer;
    }

    button:hover {
        background-color: #32496A;
    }

    .error-msg {
        background-color: #FBEAE8;
        color: #B3413A;
        padding: 10px;
        border-radius: 4px;
        margin-top: 12px;
        font-size: 14px;
        text-align: center;
    }
</style>
<body>
    <div class="container">
        <div class="content">
            <h2>Login</h2>
            <form action="login.php" method="post">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Login</button>

                <?php if (!empty($error)): ?>
                    <div class="error-msg"><?php echo $error; ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>