-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Jul 2026 pada 03.06
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apriori`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `confidence`
--

CREATE TABLE `confidence` (
  `id` int(11) NOT NULL,
  `kondisi` varchar(255) NOT NULL,
  `hasil` decimal(5,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `confidence`
--

INSERT INTO `confidence` (`id`, `kondisi`, `hasil`) VALUES
(2, 'Jika membeli Avoskin Luminous Glow Night Cream 30g maka ada kemungkinan membeli Wardah Lightening Day Gel 30g', 0.8000),
(3, 'Jika membeli Scarlett Whitening Brightly Ever After Night Cream 20g maka ada kemungkinan membeli Somethinc Supple Power Hyaluronic Toner 120ml', 1.0000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_produk`
--

CREATE TABLE `data_produk` (
  `kode_produk` varchar(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `data_produk`
--

INSERT INTO `data_produk` (`kode_produk`, `nama_produk`) VALUES
('CM-002', 'Scarlett Whitening Brightly Ever After Night Cream 20g'),
('CM-004', 'Avoskin Luminous Glow Night Cream 30g'),
('CS-001', 'Wardah Lightening Day Gel 30g'),
('CS-007', 'Garnier Sakura Glow Hyaluron Day Cream 50ml'),
('TN-001', 'Avoskin Miraculous Refining Toner 100ml'),
('TN-002', 'Somethinc Supple Power Hyaluronic Toner 120ml');

-- --------------------------------------------------------

--
-- Struktur dari tabel `support1`
--

CREATE TABLE `support1` (
  `kode_produk` varchar(11) NOT NULL,
  `jumlah_muncul` int(3) NOT NULL,
  `nilai` decimal(3,1) NOT NULL,
  `status` enum('LOLOS','TIDAK LOLOS') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `support1`
--

INSERT INTO `support1` (`kode_produk`, `jumlah_muncul`, `nilai`, `status`) VALUES
('CM-002', 4, 0.4, 'LOLOS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `support2`
--

CREATE TABLE `support2` (
  `kode_produk` varchar(255) NOT NULL,
  `muncul_bersama` int(3) NOT NULL,
  `nilai` decimal(3,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `support2`
--

INSERT INTO `support2` (`kode_produk`, `muncul_bersama`, `nilai`) VALUES
('CS-001 + TN-001', 6, 0.6),
('TN-001 + CM-004', 4, 0.4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `kode` varchar(4) NOT NULL,
  `produk` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`kode`, `produk`) VALUES
('T1', 'CS-001, TN-001, FC-003, SR-003'),
('T10', 'CS-001, TN-001, CM-004, TN-008'),
('T11', 'CM-004, CM-002'),
('T2', 'CS-001, TN-001, CM-004, TN-002'),
('T3', 'CS-007, TN-002, CM-002, SR-008'),
('T4', 'CS-001, TN-001, CM-004, FC-007'),
('T5', 'CS-007, TN-002, CM-002, CM-004'),
('T6', 'CS-001, TN-001, TN-002, SR-006'),
('T7', 'CS-007, TN-002, CM-002, FC-009'),
('T8', 'CS-001, TN-001, CM-004, SR-010'),
('T9', 'CS-007, TN-002, CM-002, TN-008');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `confidence`
--
ALTER TABLE `confidence`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `data_produk`
--
ALTER TABLE `data_produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indeks untuk tabel `support1`
--
ALTER TABLE `support1`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indeks untuk tabel `support2`
--
ALTER TABLE `support2`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`kode`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `confidence`
--
ALTER TABLE `confidence`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
