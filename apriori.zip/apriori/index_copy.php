<?php
session_start();
include 'koneksi.php';

$saved_message = '';
if (isset($_SESSION['flash_message'])) {
    $saved_message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}
$active_form = '';
if (isset($_SESSION['active_form']) && $_SESSION['active_form'] !== '') {
    $active_form = $_SESSION['active_form'];
    unset($_SESSION['active_form']);
}

// Variable form c1 & l1
$kode_produk = trim((string)($_POST['kode_produk'] ?? ''));
$jumlah_kemunculan = trim((string)($_POST['jumlah_kemunculan'] ?? ''));
$nilai_support1 = trim((string)($_POST['nilai_support1'] ?? ''));
$status = trim((string)($_POST['status'] ?? ''));
$selected_produk = '';

// Variable form c2 & l2
$cari_kode = trim((string)($_POST['cari_kode'] ?? ''));
$jumlah_kemunculan2 = trim((string)($_POST['jumlah_kemunculan2'] ?? ''));
$nilai_support2 = trim((string)($_POST['Nilai_support2'] ?? ''));
$pair_input = trim((string)($_POST['pair_input'] ?? ''));
$pair_result = trim((string)($_POST['pair_result'] ?? ''));
$pair_error = '';
$confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
$confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));
$confidence_result = trim((string)($_POST['confidence_result'] ?? ''));
$confidence_error = '';

function compactTableIds($conn, $tableName)
{
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $tableName);
    if ($safeTable === '') {
        return false;
    }

    mysqli_query($conn, 'SET @new_id = 0');
    $updateQuery = "UPDATE `$safeTable` SET id = (@new_id := @new_id + 1) ORDER BY id ASC";
    if (!mysqli_query($conn, $updateQuery)) {
        return false;
    }

    $maxResult = mysqli_query($conn, "SELECT MAX(id) AS max_id FROM `$safeTable`");
    if ($maxResult) {
        $maxRow = mysqli_fetch_assoc($maxResult);
        $maxId = (int)($maxRow['max_id'] ?? 0);
        $nextId = $maxId > 0 ? $maxId + 1 : 1;
        mysqli_query($conn, "ALTER TABLE `$safeTable` AUTO_INCREMENT = $nextId");
    }

    return true;
}

$request_method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($request_method === 'POST') {
    if (isset($_POST['delete_support1_id'])) {
        $deleteId = (int)($_POST['delete_support1_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM support1 WHERE id = $deleteId");
            compactTableIds($conn, 'support1');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php');
            exit;
        }
    }

    if (isset($_POST['delete_support2_id'])) {
        $deleteId = (int)($_POST['delete_support2_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM support2 WHERE id = $deleteId");
            compactTableIds($conn, 'support2');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php');
            exit;
        }
    }

    if (isset($_POST['delete_confidence_id'])) {
        $deleteId = (int)($_POST['delete_confidence_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM confidence WHERE id = $deleteId");
            compactTableIds($conn, 'confidence');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php');
            exit;
        }
    }

    // Handle form submission for C1 & L1
    if (isset($_POST['kode_produk']) && !isset($_POST['S1']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        $selected_produk = $kode_produk;
        $kode_produk_escaped = mysqli_real_escape_string($conn, $selected_produk);
        $query_ambil = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$kode_produk_escaped%'";
        $result_ambil = mysqli_query($conn, $query_ambil);

        if ($result_ambil) {
            $jumlah_kemunculan = mysqli_num_rows($result_ambil);
            $total_transaksi_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
            $total_transaksi_data = mysqli_fetch_assoc($total_transaksi_result);
            $total_transaksi = (int)($total_transaksi_data['total'] ?? 0);

            if ($total_transaksi > 0) {
                $nilai_support1 = round($jumlah_kemunculan / $total_transaksi, 4);
            } else {
                $nilai_support1 = 0;
            }

            if ($nilai_support1 > 0.3) {
                $status = 'LOLOS';
            } else {
                $status = 'TIDAK LOLOS';
            }

            $active_form = 'form1';
            $_SESSION['active_form'] = $active_form;
        } else {
            echo 'Error: ' . mysqli_error($conn);
        }
    } elseif (isset($_POST['S1'])) {
        $kode_produk = $_POST['kode_produk'];
        $jumlah_kemunculan = $_POST['jumlah_kemunculan'];
        $nilai_support1 = $_POST['nilai_support1'];
        $status = $_POST['status'];

        $kode_produk_escaped = mysqli_real_escape_string($conn, $kode_produk);
        $cek_duplikat = mysqli_query($conn, "SELECT 1 FROM support1 WHERE kode_produk = '$kode_produk_escaped' LIMIT 1");

        if (mysqli_num_rows($cek_duplikat) > 0) {
            header('Location: index.php');
            exit;
        }

        $query_simpan = "INSERT INTO support1 (kode_produk, jumlah_muncul, nilai, status) VALUES ('$kode_produk_escaped', '$jumlah_kemunculan', '$nilai_support1', '$status')";
        if (mysqli_query($conn, $query_simpan)) {
            $_SESSION['flash_message'] = 'Data berhasil disimpan.';
            header('Location: index.php');
            exit;
        } else {
            echo 'Error: ' . mysqli_error($conn);
        }
    }

    // Handle form submission for C2 & L2
    if (isset($_POST['cari_kode']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        if (isset($_POST['cari_hitung1'])) {
            $input_names = array_filter(array_map('trim', explode(',', $cari_kode)));
            $pair_names = [];
            $pair_codes = [];

            foreach ($input_names as $name) {
                $name_escaped = mysqli_real_escape_string($conn, $name);
                $produk_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name_escaped%') LIMIT 1");
                if ($produk_res && $produk_row = mysqli_fetch_assoc($produk_res)) {
                    $pair_names[] = $name;
                    $pair_codes[] = $produk_row['kode_produk'];
                } else {
                    $pair_error = 'Satu atau lebih nama produk tidak ditemukan.';
                }
            }

            if (empty($pair_error) && count($pair_codes) === 2) {
                $code1 = $pair_codes[0];
                $code2 = $pair_codes[1];
                $pair_result = $code1 . ' + ' . $code2;

                $query_cari = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%' AND REPLACE(produk, ' ', '') LIKE '%$code2%'";
                $result_cari = mysqli_query($conn, $query_cari);

                if ($result_cari) {
                    $jumlah_kemunculan2 = mysqli_num_rows($result_cari);
                    $total_transaksi_result2 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
                    $total_transaksi_data2 = mysqli_fetch_assoc($total_transaksi_result2);
                    $total_transaksi2 = (int)($total_transaksi_data2['total'] ?? 0);

                    if ($total_transaksi2 > 0) {
                        $nilai_support2 = round($jumlah_kemunculan2 / $total_transaksi2, 4);
                    } else {
                        $nilai_support2 = 0;
                    }

                    $active_form = 'form2';
                    $_SESSION['active_form'] = $active_form;
                } else {
                    echo 'Error: ' . mysqli_error($conn);
                }
            } else {
                $jumlah_kemunculan2 = '';
                $nilai_support2 = '';
                $pair_result = '';
                $active_form = 'form2';
            }
        } elseif (isset($_POST['S2'])) {
            $cari_kode = $_POST['cari_kode'];
            $jumlah_kemunculan2 = $_POST['jumlah_kemunculan2'];
            $nilai_support2 = $_POST['Nilai_support2'];
            $pair_result = $_POST['pair_result'];

            if ($cari_kode === '' || $jumlah_kemunculan2 === '' || $nilai_support2 === '') {
                $pair_error = 'Lakukan pencarian terlebih dahulu sebelum menyimpan.';
            } else {
                $cari_kode_escaped = mysqli_real_escape_string($conn, $pair_result);
                $cek_duplikat2 = mysqli_query($conn, "SELECT 1 FROM support2 WHERE kode_produk = '$cari_kode_escaped' LIMIT 1");

                if (mysqli_num_rows($cek_duplikat2) > 0) {
                    header('Location: index.php');
                    exit;
                }

                $query_simpan2 = "INSERT INTO support2 (kode_produk, muncul_bersama, nilai) VALUES ('$cari_kode_escaped', '$jumlah_kemunculan2', '$nilai_support2')";
                if (mysqli_query($conn, $query_simpan2)) {
                    $_SESSION['flash_message'] = 'Data berhasil disimpan.';
                    header('Location: index.php');
                    exit;
                } else {
                    echo 'Error: ' . mysqli_error($conn);
                }
            }
        }
    }

    if (isset($_POST['cari_hitung2']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        $confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
        $confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));

        if ($confidence_input1 === '' || $confidence_input2 === '') {
            $confidence_error = 'Masukkan dua nama produk terlebih dahulu.';
        } else {
            $name1_escaped = mysqli_real_escape_string($conn, $confidence_input1);
            $name2_escaped = mysqli_real_escape_string($conn, $confidence_input2);

            $produk1_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name1_escaped%') LIMIT 1");
            $produk2_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name2_escaped%') LIMIT 1");

            if ($produk1_res && $produk2_res) {
                $produk1_row = mysqli_fetch_assoc($produk1_res);
                $produk2_row = mysqli_fetch_assoc($produk2_res);

                if ($produk1_row && $produk2_row) {
                    $code1 = $produk1_row['kode_produk'];
                    $code2 = $produk2_row['kode_produk'];

                    $support1_query = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%'";
                    $support1_result = mysqli_query($conn, $support1_query);
                    $support1_count = $support1_result ? mysqli_num_rows($support1_result) : 0;

                    $total_transaksi_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
                    $total_transaksi_data = mysqli_fetch_assoc($total_transaksi_result);
                    $total_transaksi = (int)($total_transaksi_data['total'] ?? 0);
                    $support1_value = $total_transaksi > 0 ? round($support1_count / $total_transaksi, 4) : 0;

                    $support2_query = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%' AND REPLACE(produk, ' ', '') LIKE '%$code2%'";
                    $support2_result = mysqli_query($conn, $support2_query);
                    $support2_count = $support2_result ? mysqli_num_rows($support2_result) : 0;
                    $support2_value = $total_transaksi > 0 ? round($support2_count / $total_transaksi, 4) : 0;

                    $confidence_value = $support1_value > 0 ? round($support2_value / $support1_value, 4) : 0;
                    $confidence_result = (string)$confidence_value;
                    $active_form = 'form3';
                    $_SESSION['active_form'] = $active_form;
                } else {
                    $confidence_error = 'Satu atau lebih nama produk tidak ditemukan.';
                }
            } else {
                $confidence_error = 'Gagal membaca data produk.';
            }
        }
    } elseif (isset($_POST['simpan2'])) {
        $confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
        $confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));
        $confidence_result = trim((string)($_POST['confidence_result'] ?? ''));

        if ($confidence_input1 === '' || $confidence_input2 === '' || $confidence_result === '') {
            $confidence_error = 'Lakukan perhitungan confidence terlebih dahulu.';
        } else {
            $name1_escaped = mysqli_real_escape_string($conn, $confidence_input1);
            $name2_escaped = mysqli_real_escape_string($conn, $confidence_input2);

            $produk1_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name1_escaped%') LIMIT 1");
            $produk2_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name2_escaped%') LIMIT 1");

            if ($produk1_res && $produk2_res) {
                $produk1_row = mysqli_fetch_assoc($produk1_res);
                $produk2_row = mysqli_fetch_assoc($produk2_res);

                if ($produk1_row && $produk2_row) {
                    $code1 = $produk1_row['kode_produk'];
                    $code2 = $produk2_row['kode_produk'];
                    $pair_label = 'Jika membeli ' . $confidence_input1 . ' maka ada kemungkinan membeli ' . $confidence_input2;

                    mysqli_query($conn, "ALTER TABLE confidence MODIFY hasil DECIMAL(5,4)");
                    $insert_confidence = "INSERT INTO confidence (kondisi, hasil) VALUES ('$pair_label', '$confidence_result')";
                    if (mysqli_query($conn, $insert_confidence)) {
                        $_SESSION['flash_message'] = 'Data berhasil disimpan.';
                        header('Location: index.php');
                        exit;
                    } else {
                        echo 'Error: ' . mysqli_error($conn);
                    }
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perhitungan Apriori</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        /* ============================================
           PERHITUNGAN APRIORI — Admin Dashboard
           Tema: terang, profesional, warna restrained
           ============================================ */

        :root {
            --bg: #F1F3F6;
            --surface: #FFFFFF;
            --border: #E3E6EB;
            --border-strong: #D3D7DE;
            --text-primary: #1F2937;
            --text-secondary: #5B6472;
            --text-muted: #9AA1AC;
            --accent: #3D5A80;
            --accent-hover: #32496A;
            --accent-soft: #E8EEF4;
            --success: #2F7D5C;
            --success-soft: #E4F3EC;
            --danger: #B3413A;
            --danger-soft: #FBEAE8;
            --radius-lg: 14px;
            --radius-md: 10px;
            --radius-sm: 8px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            color: var(--text-primary);
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 10px; height: 10px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 999px; }
        ::-webkit-scrollbar-thumb:hover { background: #B8BFC9; }

        button:focus-visible, li:focus-visible {
            outline: 2px solid var(--accent);
            outline-offset: 2px;
        }

        /* ===== Layout shell ===== */
        .container { display: flex; min-height: 100vh; }

        /* ===== Sidebar ===== */
        .kiri {
            width: 256px;
            flex-shrink: 0;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 28px 20px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .headKir span {
            font-weight: 700;
            font-size: 1.05rem;
            letter-spacing: -0.01em;
            color: var(--text-primary);
            position: relative;
            padding-left: 16px;
        }

        .headKir span::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--accent);
        }

        .kiri hr { border: none; border-top: 1px solid var(--border); }

        .kiri ul { list-style: none; display: flex; flex-direction: column; gap: 3px; }

        .kiri li {
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            font-size: .9rem;
            font-weight: 500;
            color: var(--text-secondary);
            cursor: pointer;
            border-left: 2px solid transparent;
            transition: background .15s ease, color .15s ease, border-color .15s ease;
        }

        .kiri li:hover { background: var(--accent-soft); color: var(--accent); }

        .kiri li:first-child {
            background: var(--accent-soft);
            color: var(--accent);
            border-left-color: var(--accent);
            font-weight: 600;
        }

        /* ===== Main content ===== */
        .kanan {
            flex: 1;
            min-width: 0;
            position: relative;
            padding: 32px 40px 56px;
        }

        .kanan > header {
            display: block;
            font-weight: 700;
            font-size: 1.3rem;
            letter-spacing: 0.01em;
            color: var(--text-primary);
            padding-bottom: 16px;
            margin-bottom: 24px;
            padding-right: 170px;
            border-bottom: 1px solid var(--border);
        }

        .adminBarKanan {
            position: absolute;
            top: 32px;
            right: 40px;
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--surface);
            border: 1px solid var(--border);
            padding: 6px 16px 6px 6px;
            border-radius: 999px;
        }

        .adminBarKanan span:first-child {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--accent);
            color: #fff;
            font-weight: 700;
            font-size: .78rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .adminBarKanan span:last-child {
            font-size: .84rem;
            font-weight: 600;
            color: var(--text-secondary);
        }

        .containerKan { display: flex; flex-direction: column; gap: 22px; }

        /* ===== Cards ===== */
        .buttonArea, .tableArea {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 22px 26px;
            box-shadow: 0 1px 2px rgba(16,24,40,0.04), 0 1px 3px rgba(16,24,40,0.06);
        }

        .text span, .textt span {
            font-size: .74rem;
            font-weight: 600;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--text-muted);
            display: block;
            margin-bottom: 14px;
        }

        /* ===== Stage steps (Apriori = proses berurutan: C1&L1 -> C2&L2 -> Confidence) ===== */
        .btn, .tabelbtn {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            counter-reset: stage;
        }

        .btn::before, .tabelbtn::before {
            content: '';
            position: absolute;
            left: 18px;
            right: 18px;
            top: 50%;
            height: 1px;
            background: var(--border-strong);
            z-index: 0;
            pointer-events: none;
        }

        .btn button, .tabelbtn button {
            counter-increment: stage;
            position: relative;
            z-index: 1;
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: .84rem;
            color: var(--text-secondary);
            background: var(--surface);
            border: 1px solid var(--border-strong);
            padding: 9px 20px 9px 30px;
            border-radius: 999px;
            margin: 4px 12px 4px 0;
            cursor: pointer;
            transition: border-color .15s ease, color .15s ease, background .15s ease;
        }

        .btn button:last-child, .tabelbtn button:last-child { margin-right: 0; }

        .btn button::before, .tabelbtn button::before {
            content: counter(stage);
            position: absolute;
            left: 9px;
            top: 50%;
            transform: translateY(-50%);
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: var(--bg);
            color: var(--text-muted);
            font-family: 'IBM Plex Mono', monospace;
            font-size: .62rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn button:hover, .tabelbtn button:hover {
            border-color: var(--accent);
            color: var(--accent);
        }

        .btn button.active, .tabelbtn button.active {
            background: var(--accent);
            color: #fff;
            border-color: var(--accent);
        }

        .btn button.active::before, .tabelbtn button.active::before {
            background: rgba(255,255,255,0.2);
            color: #fff;
        }

        /* ===== Tables ===== */
        .table { margin-top: 20px; }

        .table1, .table2, .table3 { display: none; overflow-x: auto; }

        .table1.active, .table2.active, .table3.active {
            display: block;
            animation: fadeIn .2s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(3px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes modalAppear {
            from {
                opacity: 0;
                transform: translate(-50%, -48%) scale(0.97);
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }

        .titleT {
            font-weight: 700;
            font-size: .98rem;
            color: var(--text-primary);
            display: block;
            margin-bottom: 12px;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            overflow: hidden;
        }

        th {
            font-size: .7rem;
            font-weight: 600;
            letter-spacing: .06em;
            text-transform: uppercase;
            color: var(--text-muted);
            background: #FAFBFC;
            text-align: left;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 11px 16px;
            font-size: .87rem;
            font-family: 'IBM Plex Mono', monospace;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border);
        }

        tr:last-child td { border-bottom: none; }
        tr:hover td { background: #FAFBFC; }

        .form {
            margin-top: 24px;
            display: flex;
            align-items: flex-start;
            position: relative;
        }

        .form1, .form2, .form3 {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: min(92vw, 720px);
            max-width: 720px;
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 24px 24px 20px;
            box-shadow: 0 18px 45px rgba(15, 23, 42, 0.18);
            z-index: 1200;
        }

        .form1.active, .form2.active, .form3.active {
            display: block;
            animation: modalAppear .22s ease;
        }

        .form::before {
            content: '';
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            z-index: 1100;
            display: none;
            pointer-events: none;
        }

        .form:has(.form1.active)::before,
        .form:has(.form2.active)::before,
        .form:has(.form3.active)::before {
            display: block;
        }

        .form-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border);
        }

        .form-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text-primary);
        }

        .close-form {
            width: 34px;
            height: 34px;
            border: none;
            border-radius: 50%;
            background: var(--danger-soft);
            color: var(--danger);
            font-size: 1.1rem;
            line-height: 1;
            cursor: pointer;
            transition: background .15s ease, color .15s ease, transform .15s ease;
        }

        .close-form:hover {
            background: var(--danger);
            color: #fff;
            transform: rotate(90deg);
        }

        .form-row {
            display: grid;
            gap: 14px;
            margin-bottom: 14px;
        }

        .textf1 {
            display: block;
            font-size: .8rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }

        .form input, .form select {
            width: 100%;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 11px 12px;
            font-size: .9rem;
            color: var(--text-primary);
            background: #fcfcfd;
            transition: border-color .15s ease, box-shadow .15s ease;
        }

        .form input:focus, .form select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(61, 90, 128, 0.12);
        }

        .form button[type="submit"] {
            margin-top: 8px;
            padding: 10px 16px;
            border: none;
            border-radius: var(--radius-sm);
            background: var(--accent);
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            transition: background .15s ease;
        }

        .form button[type="submit"]:hover {
            background: var(--accent-hover);
        }

        /* Opsional, dipakai dari PHP buat kolom "Status":
           <span class="badge badge-lolos">Lolos</span> / <span class="badge badge-gugur">Gugur</span> */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 3px 11px;
            border-radius: 999px;
            font-family: 'Inter', sans-serif;
            font-size: .72rem;
            font-weight: 600;
        }
        .badge::before { content: ''; width: 6px; height: 6px; border-radius: 50%; background: currentColor; }
        .badge-lolos { background: var(--success-soft); color: var(--success); }
        .badge-gugur { background: var(--danger-soft); color: var(--danger); }

        /* ===== Responsive ===== */
        @media (max-width: 860px) {
            .container { flex-direction: column; }
            .kiri {
                width: 100%;
                flex-direction: row;
                align-items: center;
                justify-content: space-between;
                padding: 14px 20px;
            }
            .kiri hr { display: none; }
            .kiri ul { flex-direction: row; }
            .kanan { padding: 84px 20px 40px; }
            .kanan > header { padding-right: 0; }
            .adminBarKanan { top: 14px; right: 20px; }
            .btn::before, .tabelbtn::before { display: none; }
        }

        @media (prefers-reduced-motion: reduce) {
            * { animation: none !important; transition: none !important; }
        }
    </style>
</head>
<body>
    <?php if ($saved_message !== ''): ?>
        <script>
            alert('<?php echo addslashes($saved_message); ?>');
        </script>
    <?php endif; ?>
    <div class="container">

        <div class="kiri">
            <div class="headKir">
                <span>Admin</span>
            </div>
            <hr>
            <ul>
                <li>Data Apriori</li>
            </ul>
        </div>

        <div class="kanan">
            <header>PERHITUNGAN DATA APRIORI</header>
            <div class="adminBarKanan">
                <span>A</span>
                <span>Admin</span>
            </div>
            <div class="containerKan">
                <div class="buttonArea">
                    <div class="text"><span>Hitung:</span></div>
                    <div class="btn">
                    <button type="button" class="sup1F<?php echo $active_form === 'form1' ? ' active' : ''; ?>">C1 & L1</button>
                    <button type="button" class="sup2F">C2 & L2</button>
                    <button type="button" class="ConF">Confidence</button>
                    </div>
                </div>
                <div class="tableArea">
                    <div class="textt"><span>Daftar Table:</span></div>
                    <div class="tabelbtn">
                    <button type="button" class="sup1 active">C1 & L1</button>
                    <button type="button" class="sup2">C2 & L2</button>
                    <button type="button" class="Con">Confidence</button>
                    </div>
                    <div class="table">
                        <div class="table1 active">
                            <span class="titleT">C1 & L1</span>
                            <table>
                                <tr>
                                    <th>Kode Produk</th>
                                    <th>Jumlah Kemunculan</th>
                                    <th>Nilai Support</th>
                                    <th>Status</th>
                                </tr>
                                <?php
                                $support1_result = mysqli_query($conn, "SELECT * FROM support1");
                                if ($support1_result) {
                                    while ($row = mysqli_fetch_assoc($support1_result)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($row['kode_produk'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['jumlah_muncul'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['nilai'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['status'], ENT_QUOTES) . '</td>';
                                        echo '</tr>';
                                    }
                                }
                                ?>
                            </table>
                        </div>

                        <div class="table2">
                            <span class="titleT">C2 & L2</span>
                            <table>
                                <tr>
                                    <th>No</th>
                                    <th>Kombinasi Itemset</th>
                                    <th>Jumlah Kemunculan Bersama</th>
                                    <th>Nilai Support</th>
                                    <th>Aksi</th>
                                </tr>
                                <?php
                                $support2_result = mysqli_query($conn, "SELECT * FROM support2 ORDER BY id ASC");
                                if ($support2_result) {
                                    while ($row = mysqli_fetch_assoc($support2_result)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($row['id'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['kode_produk'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['muncul_bersama'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['nilai'], ENT_QUOTES) . '</td>';
                                        echo '<td>';
                                        echo '<form method="post" style="display:inline;">';
                                        echo '<input type="hidden" name="delete_support2_id" value="' . (int)$row['id'] . '">';
                                        echo '<button type="submit" style="padding:6px 10px; border:none; border-radius:6px; background:var(--danger-soft); color:var(--danger); cursor:pointer;">Hapus</button>';
                                        echo '</form>';
                                        echo '</td>';
                                        echo '</tr>';
                                    }
                                }
                                ?>
                            </table>
                        </div>

                        <div class="table3">
                            <span class="titleT">Confidence</span>
                            <table>
                                <tr>
                                    <th>Kondisi</th>
                                    <th>Hasil</th>
                                    <th>Aksi</th>
                                </tr>
                                <?php
                                $confidence_result_db = mysqli_query($conn, "SELECT * FROM confidence ORDER BY id ASC");
                                if ($confidence_result_db) {
                                    while ($row = mysqli_fetch_assoc($confidence_result_db)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($row['kondisi'], ENT_QUOTES) . '</td>';
                                        echo '<td>' . htmlspecialchars($row['hasil'], ENT_QUOTES) . '</td>';
                                        echo '<td>';
                                        echo '<form method="post" style="display:inline;">';
                                        echo '<input type="hidden" name="delete_confidence_id" value="' . (int)$row['id'] . '">';
                                        echo '<button type="submit" style="padding:6px 10px; border:none; border-radius:6px; background:var(--danger-soft); color:var(--danger); cursor:pointer;">Hapus</button>';
                                        echo '</form>';
                                        echo '</td>';
                                        echo '</tr>';
                                    }
                                }
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="form">
            <div class="form1<?php echo $active_form === 'form1' ? ' active' : ''; ?>">
                <div class="form-head">
                    <span class="form-title">Hitung C1 & L1</span>
                    <button type="button" class="close-form" aria-label="Tutup form" data-form="1">×</button>
                </div>
                <form action="#" method="post">
                    <div class="form-row">
                        <div>
                            <span class="textf1">Kode Produk</span>
                            <select name="kode_produk" onchange="this.form.submit()">
                                <option value="">-- Pilih Produk --</option>
                                <?php
                                $query_produk = "SELECT * FROM data_produk";
                                $result_produk = mysqli_query($conn, $query_produk);
                                while ($row_produk = mysqli_fetch_assoc($result_produk)) {
                                    $is_selected = ($selected_produk !== '' && $row_produk['kode_produk'] === $selected_produk) ? ' selected' : '';
                                ?>
                                <option value="<?php echo htmlspecialchars($row_produk['kode_produk'], ENT_QUOTES); ?>"<?php echo $is_selected; ?>><?php echo htmlspecialchars($row_produk['nama_produk'], ENT_QUOTES); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div>
                            <span class="textf1">Jumlah Kemunculan</span>
                            <input type="text" name="jumlah_kemunculan" readonly value="<?php echo htmlspecialchars((string)($jumlah_kemunculan ?? ''), ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Nilai Support</span>
                            <input type="text" name="nilai_support1" readonly value="<?php echo htmlspecialchars((string)($nilai_support1 ?? ''), ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Status</span>
                            <input type="text" name="status" readonly value="<?php echo htmlspecialchars((string)($status ?? ''), ENT_QUOTES); ?>">
                        </div>
                    </div>
                    <button type="submit" name="S1">Simpan</button>
                </form>
            </div>

            <div class="form2<?php echo $active_form === 'form2' ? ' active' : ''; ?>">
                <div class="form-head">
                    <span class="form-title">Hitung C2 & L2</span>
                    <button type="button" class="close-form" aria-label="Tutup form" data-form="2">×</button>
                </div>
                <form action="#" method="post">
                    <div class="form-row">
                        <div>
                            <span class="textf1">Nama Produk 1, Nama Produk 2</span>
                            <input type="text" name="cari_kode" placeholder="Contoh: Scarlett Whitening, Avoskin" value="<?php echo htmlspecialchars($cari_kode, ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Pasangan Produk</span>
                            <input type="text" name="pair_result" readonly value="<?php echo htmlspecialchars($pair_result, ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Jumlah Kemunculan Bersama</span>
                            <input type="text" name="jumlah_kemunculan2" readonly value="<?php echo htmlspecialchars($jumlah_kemunculan2, ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Nilai Support</span>
                            <input type="text" name="Nilai_support2" readonly value="<?php echo htmlspecialchars($nilai_support2, ENT_QUOTES); ?>">
                        </div>
                        <?php if ($pair_error !== ''): ?>
                            <div style="color: var(--danger); font-size: .8rem; font-weight: 600;"><?php echo htmlspecialchars($pair_error, ENT_QUOTES); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" name="cari_hitung1">Cari & Hitung</button>
                    <button type="submit" name="S2">Simpan</button>
                </form>
            </div>

            <div class="form3<?php echo $active_form === 'form3' ? ' active' : ''; ?>">
                <div class="form-head">
                    <span class="form-title">Confidence</span>
                    <button type="button" class="close-form" aria-label="Tutup form" data-form="3">×</button>
                </div>
                <form action="#" method="post">
                    <div class="form-row">
                        <div>
                            <span class="textf1">Nama Produk 1</span>
                            <input type="text" name="confidence_input1" placeholder="Jika Membeli..." value="<?php echo htmlspecialchars($confidence_input1, ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Nama Produk 2</span>
                            <input type="text" name="confidence_input2" placeholder="Maka Akan Membeli..." value="<?php echo htmlspecialchars($confidence_input2, ENT_QUOTES); ?>">
                        </div>
                        <div>
                            <span class="textf1">Hasil</span>
                            <input type="text" name="confidence_result" readonly value="<?php echo htmlspecialchars($confidence_result, ENT_QUOTES); ?>">
                        </div>
                        <?php if ($confidence_error !== ''): ?>
                            <div style="color: var(--danger); font-size: .8rem; font-weight: 600;"><?php echo htmlspecialchars($confidence_error, ENT_QUOTES); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" name="cari_hitung2">Cari & Hitung</button>
                    <button type="submit" name="simpan2">Simpan</button>
                </form>
            </div>
        </div>

    </div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const table1 = document.querySelector('.table1');
        const table2 = document.querySelector('.table2');
        const table3 = document.querySelector('.table3');
        const sup1 = document.querySelector('.sup1');
        const sup2 = document.querySelector('.sup2');
        const Con = document.querySelector('.Con');
        const form1 = document.querySelector('.form1');
        const form2 = document.querySelector('.form2');
        const form3 = document.querySelector('.form3');
        const btnForm1 = document.querySelector('.sup1F');
        const btnForm2 = document.querySelector('.sup2F');
        const btnForm3 = document.querySelector('.ConF');
        const closeButtons = document.querySelectorAll('.close-form');

        const state = {
            currentTable: 'table1',
            currentForm: null
        };

        function clearTableState() {
            [table1, table2, table3].forEach((table) => table && table.classList.remove('active'));
            [sup1, sup2, Con].forEach((button) => button && button.classList.remove('active'));
        }

        function clearFormState() {
            [form1, form2, form3].forEach((form) => form && form.classList.remove('active'));
            [btnForm1, btnForm2, btnForm3].forEach((button) => button && button.classList.remove('active'));
        }

        function showTable(nomor) {
            clearTableState();
            clearFormState();
            state.currentForm = null;

            if (nomor === 1) {
                if (table1) table1.classList.add('active');
                if (sup1) sup1.classList.add('active');
                state.currentTable = 'table1';
            } else if (nomor === 2) {
                if (table2) table2.classList.add('active');
                if (sup2) sup2.classList.add('active');
                state.currentTable = 'table2';
            } else if (nomor === 3) {
                if (table3) table3.classList.add('active');
                if (Con) Con.classList.add('active');
                state.currentTable = 'table3';
            }
        }

        function closeForm() {
            clearFormState();
            state.currentForm = null;
        }

        function showForm(nomor2) {
            clearFormState();
            clearTableState();
            state.currentTable = null;

            if (nomor2 === 11) {
                if (form1) form1.classList.add('active');
                if (btnForm1) btnForm1.classList.add('active');
                state.currentForm = 'form1';
            } else if (nomor2 === 12) {
                if (form2) form2.classList.add('active');
                if (btnForm2) btnForm2.classList.add('active');
                state.currentForm = 'form2';
            } else if (nomor2 === 13) {
                if (form3) form3.classList.add('active');
                if (btnForm3) btnForm3.classList.add('active');
                state.currentForm = 'form3';
            }
        }

        if (sup1) sup1.addEventListener('click', () => showTable(1));
        if (sup2) sup2.addEventListener('click', () => showTable(2));
        if (Con) Con.addEventListener('click', () => showTable(3));
        if (btnForm1) btnForm1.addEventListener('click', () => showForm(11));
        if (btnForm2) btnForm2.addEventListener('click', () => showForm(12));
        if (btnForm3) btnForm3.addEventListener('click', () => showForm(13));
        closeButtons.forEach((button) => {
            button.addEventListener('click', () => closeForm());
        });

        showTable(1);
    })
</script>
</html>