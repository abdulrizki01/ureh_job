<?php

session_start();

if (!isset($_SESSION['admin_login']) || $_SESSION['admin_login'] !== true) {
    header('Location: login.php');
    exit;
}

include 'koneksi.php';

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

$saved_message = '';
if (isset($_SESSION['flash_message'])) {
    $saved_message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}
$active_form = '';
if (isset($_SESSION['active_form']) && $_SESSION['active_form'] !== '') {
    $active_form = $_SESSION['active_form'];
    unset($_SESSION['active_form']);
}

// Variable untuk menu aktif
$active_menu = isset($_SESSION['active_menu']) ? $_SESSION['active_menu'] : 'apriori';
if (isset($_GET['menu'])) {
    $active_menu = $_GET['menu'];
    $_SESSION['active_menu'] = $active_menu;
}

// Variable form c1 & l1
$kode_produk = trim((string)($_POST['kode_produk'] ?? ''));
$jumlah_kemunculan = trim((string)($_POST['jumlah_kemunculan'] ?? ''));
$nilai_support1 = trim((string)($_POST['nilai_support1'] ?? ''));
$status = trim((string)($_POST['status'] ?? ''));
$selected_produk = '';

// Variable form c2 & l2
$cari_kode = trim((string)($_POST['cari_kode'] ?? ''));
$jumlah_kemunculan2 = trim((string)($_POST['jumlah_kemunculan2'] ?? ''));
$nilai_support2 = trim((string)($_POST['Nilai_support2'] ?? ''));
$pair_input = trim((string)($_POST['pair_input'] ?? ''));
$pair_result = trim((string)($_POST['pair_result'] ?? ''));
$pair_error = '';
$confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
$confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));
$confidence_result = trim((string)($_POST['confidence_result'] ?? ''));
$confidence_error = '';

// Variable form data produk
// NOTE: field names are prefixed with "produk_" on purpose so they never collide
// with the "kode_produk" field already used by the C1 & L1 (Apriori) form above.
$produk_kode = trim((string)($_POST['produk_kode'] ?? ''));
$produk_nama = trim((string)($_POST['produk_nama'] ?? ''));
$produk_error = '';

// Variable form data transaksi
$transaksi_produk_selected = (isset($_POST['transaksi_produk']) && is_array($_POST['transaksi_produk']))
    ? $_POST['transaksi_produk']
    : [];
$transaksi_error = '';

function compactTableIds($conn, $tableName)
{
    $safeTable = preg_replace('/[^a-zA-Z0-9_]/', '', $tableName);
    if ($safeTable === '') {
        return false;
    }

    mysqli_query($conn, 'SET @new_id = 0');
    $updateQuery = "UPDATE `$safeTable` SET id = (@new_id := @new_id + 1) ORDER BY id ASC";
    if (!mysqli_query($conn, $updateQuery)) {
        return false;
    }

    $maxResult = mysqli_query($conn, "SELECT MAX(id) AS max_id FROM `$safeTable`");
    if ($maxResult) {
        $maxRow = mysqli_fetch_assoc($maxResult);
        $maxId = (int)($maxRow['max_id'] ?? 0);
        $nextId = $maxId > 0 ? $maxId + 1 : 1;
        mysqli_query($conn, "ALTER TABLE `$safeTable` AUTO_INCREMENT = $nextId");
    }

    return true;
}

// Generate kode transaksi otomatis lanjut dari yang terakhir (T1, T2, T3, ...)
function generateKodeTransaksi($conn)
{
    $query = "SELECT kode FROM transaksi WHERE kode REGEXP '^T[0-9]+$' ORDER BY CAST(SUBSTRING(kode, 2) AS UNSIGNED) DESC LIMIT 1";
    $result = mysqli_query($conn, $query);

    $nomor_terakhir = 0;
    if ($result && $row = mysqli_fetch_assoc($result)) {
        $nomor_terakhir = (int)substr($row['kode'], 1);
    }

    $nomor_baru = $nomor_terakhir + 1;
    return 'T' . $nomor_baru;
}

$request_method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($request_method === 'POST') {
    // Handle Apriori forms
    if (isset($_POST['delete_support1_id'])) {
        $deleteId = (int)($_POST['delete_support1_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM support1 WHERE id = $deleteId");
            compactTableIds($conn, 'support1');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php?menu=apriori');
            exit;
        }
    }

    if (isset($_POST['delete_support2_id'])) {
        $deleteId = (int)($_POST['delete_support2_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM support2 WHERE id = $deleteId");
            compactTableIds($conn, 'support2');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php?menu=apriori');
            exit;
        }
    }

    if (isset($_POST['delete_confidence_id'])) {
        $deleteId = (int)($_POST['delete_confidence_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM confidence WHERE id = $deleteId");
            compactTableIds($conn, 'confidence');
            $_SESSION['flash_message'] = 'Data berhasil dihapus.';
            header('Location: index.php?menu=apriori');
            exit;
        }
    }

    // Handle form submission for C1 & L1
    if (isset($_POST['kode_produk']) && !isset($_POST['S1']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        $selected_produk = $kode_produk;
        $kode_produk_escaped = mysqli_real_escape_string($conn, $selected_produk);
        $query_ambil = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$kode_produk_escaped%'";
        $result_ambil = mysqli_query($conn, $query_ambil);

        if ($result_ambil) {
            $jumlah_kemunculan = mysqli_num_rows($result_ambil);
            $total_transaksi_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
            $total_transaksi_data = mysqli_fetch_assoc($total_transaksi_result);
            $total_transaksi = (int)($total_transaksi_data['total'] ?? 0);

            if ($total_transaksi > 0) {
                $nilai_support1 = round($jumlah_kemunculan / $total_transaksi, 4);
            } else {
                $nilai_support1 = 0;
            }

            if ($nilai_support1 > 0.3) {
                $status = 'LOLOS';
            } else {
                $status = 'TIDAK LOLOS';
            }

            $active_form = 'form1';
            $_SESSION['active_form'] = $active_form;
        } else {
            echo 'Error: ' . mysqli_error($conn);
        }
    } elseif (isset($_POST['S1'])) {
        $kode_produk = $_POST['kode_produk'];
        $jumlah_kemunculan = $_POST['jumlah_kemunculan'];
        $nilai_support1 = $_POST['nilai_support1'];
        $status = $_POST['status'];

        $kode_produk_escaped = mysqli_real_escape_string($conn, $kode_produk);
        $cek_duplikat = mysqli_query($conn, "SELECT 1 FROM support1 WHERE kode_produk = '$kode_produk_escaped' LIMIT 1");

        if (mysqli_num_rows($cek_duplikat) > 0) {
            $_SESSION['active_form'] = 'form1';
            $_SESSION['flash_message'] = 'Data sudah pernah disimpan sebelumnya.';
            header('Location: index.php?menu=apriori');
            exit;
        }

        $query_simpan = "INSERT INTO support1 (kode_produk, jumlah_muncul, nilai, status) VALUES ('$kode_produk_escaped', '$jumlah_kemunculan', '$nilai_support1', '$status')";
        if (mysqli_query($conn, $query_simpan)) {
            $_SESSION['active_form'] = 'form1';
            $_SESSION['flash_message'] = 'Data berhasil disimpan.';
            header('Location: index.php?menu=apriori');
            exit;
        } else {
            echo 'Error: ' . mysqli_error($conn);
        }
    }

    // Handle form submission for C2 & L2
    if (isset($_POST['cari_kode']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        if (isset($_POST['cari_hitung1'])) {
            $input_names = array_filter(array_map('trim', explode(',', $cari_kode)));
            $pair_names = [];
            $pair_codes = [];

            foreach ($input_names as $name) {
                $name_escaped = mysqli_real_escape_string($conn, $name);
                $produk_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name_escaped%') LIMIT 1");
                if ($produk_res && $produk_row = mysqli_fetch_assoc($produk_res)) {
                    $pair_names[] = $name;
                    $pair_codes[] = $produk_row['kode_produk'];
                } else {
                    $pair_error = 'Satu atau lebih nama produk tidak ditemukan.';
                }
            }

            if (empty($pair_error) && count($pair_codes) === 2) {
                $code1 = $pair_codes[0];
                $code2 = $pair_codes[1];
                $pair_result = $code1 . ' + ' . $code2;

                $query_cari = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%' AND REPLACE(produk, ' ', '') LIKE '%$code2%'";
                $result_cari = mysqli_query($conn, $query_cari);

                if ($result_cari) {
                    $jumlah_kemunculan2 = mysqli_num_rows($result_cari);
                    $total_transaksi_result2 = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
                    $total_transaksi_data2 = mysqli_fetch_assoc($total_transaksi_result2);
                    $total_transaksi2 = (int)($total_transaksi_data2['total'] ?? 0);

                    if ($total_transaksi2 > 0) {
                        $nilai_support2 = round($jumlah_kemunculan2 / $total_transaksi2, 4);
                    } else {
                        $nilai_support2 = 0;
                    }

                    $active_form = 'form2';
                    $_SESSION['active_form'] = $active_form;
                } else {
                    echo 'Error: ' . mysqli_error($conn);
                }
            } else {
                $jumlah_kemunculan2 = '';
                $nilai_support2 = '';
                $pair_result = '';
                $active_form = 'form2';
            }
        } elseif (isset($_POST['S2'])) {
            $cari_kode = $_POST['cari_kode'];
            $jumlah_kemunculan2 = $_POST['jumlah_kemunculan2'];
            $nilai_support2 = $_POST['Nilai_support2'];
            $pair_result = $_POST['pair_result'];

            if ($cari_kode === '' || $jumlah_kemunculan2 === '' || $nilai_support2 === '') {
                $pair_error = 'Lakukan pencarian terlebih dahulu sebelum menyimpan.';
                $active_form = 'form2';
            } else {
                $cari_kode_escaped = mysqli_real_escape_string($conn, $pair_result);
                $cek_duplikat2 = mysqli_query($conn, "SELECT 1 FROM support2 WHERE kode_produk = '$cari_kode_escaped' LIMIT 1");

                if (mysqli_num_rows($cek_duplikat2) > 0) {
                    $_SESSION['active_form'] = 'form2';
                    $_SESSION['flash_message'] = 'Data sudah pernah disimpan sebelumnya.';
                    header('Location: index.php?menu=apriori');
                    exit;
                }

                $query_simpan2 = "INSERT INTO support2 (kode_produk, muncul_bersama, nilai) VALUES ('$cari_kode_escaped', '$jumlah_kemunculan2', '$nilai_support2')";
                if (mysqli_query($conn, $query_simpan2)) {
                    $_SESSION['active_form'] = 'form2';
                    $_SESSION['flash_message'] = 'Data berhasil disimpan.';
                    header('Location: index.php?menu=apriori');
                    exit;
                } else {
                    echo 'Error: ' . mysqli_error($conn);
                }
            }
        }
    }

    if (isset($_POST['cari_hitung2']) && !isset($_POST['delete_support1_id']) && !isset($_POST['delete_support2_id']) && !isset($_POST['delete_confidence_id'])) {
        $confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
        $confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));

        if ($confidence_input1 === '' || $confidence_input2 === '') {
            $confidence_error = 'Masukkan dua nama produk terlebih dahulu.';
            $active_form = 'form3';
        } else {
            $name1_escaped = mysqli_real_escape_string($conn, $confidence_input1);
            $name2_escaped = mysqli_real_escape_string($conn, $confidence_input2);

            $produk1_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name1_escaped%') LIMIT 1");
            $produk2_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name2_escaped%') LIMIT 1");

            if ($produk1_res && $produk2_res) {
                $produk1_row = mysqli_fetch_assoc($produk1_res);
                $produk2_row = mysqli_fetch_assoc($produk2_res);

                if ($produk1_row && $produk2_row) {
                    $code1 = $produk1_row['kode_produk'];
                    $code2 = $produk2_row['kode_produk'];

                    $support1_query = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%'";
                    $support1_result = mysqli_query($conn, $support1_query);
                    $support1_count = $support1_result ? mysqli_num_rows($support1_result) : 0;

                    $total_transaksi_result = mysqli_query($conn, "SELECT COUNT(*) AS total FROM transaksi");
                    $total_transaksi_data = mysqli_fetch_assoc($total_transaksi_result);
                    $total_transaksi = (int)($total_transaksi_data['total'] ?? 0);
                    $support1_value = $total_transaksi > 0 ? round($support1_count / $total_transaksi, 4) : 0;

                    $support2_query = "SELECT * FROM transaksi WHERE REPLACE(produk, ' ', '') LIKE '%$code1%' AND REPLACE(produk, ' ', '') LIKE '%$code2%'";
                    $support2_result = mysqli_query($conn, $support2_query);
                    $support2_count = $support2_result ? mysqli_num_rows($support2_result) : 0;
                    $support2_value = $total_transaksi > 0 ? round($support2_count / $total_transaksi, 4) : 0;

                    $confidence_value = $support1_value > 0 ? round($support2_value / $support1_value, 4) : 0;
                    $confidence_result = (string)$confidence_value;
                    $active_form = 'form3';
                    $_SESSION['active_form'] = $active_form;
                } else {
                    $confidence_error = 'Satu atau lebih nama produk tidak ditemukan.';
                    $active_form = 'form3';
                }
            } else {
                $confidence_error = 'Gagal membaca data produk.';
                $active_form = 'form3';
            }
        }
    } elseif (isset($_POST['simpan2'])) {
        $confidence_input1 = trim((string)($_POST['confidence_input1'] ?? ''));
        $confidence_input2 = trim((string)($_POST['confidence_input2'] ?? ''));
        $confidence_result = trim((string)($_POST['confidence_result'] ?? ''));

        if ($confidence_input1 === '' || $confidence_input2 === '' || $confidence_result === '') {
            $confidence_error = 'Lakukan perhitungan confidence terlebih dahulu.';
            $active_form = 'form3';
        } else {
            $name1_escaped = mysqli_real_escape_string($conn, $confidence_input1);
            $name2_escaped = mysqli_real_escape_string($conn, $confidence_input2);

            $produk1_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name1_escaped%') LIMIT 1");
            $produk2_res = mysqli_query($conn, "SELECT kode_produk FROM data_produk WHERE LOWER(nama_produk) LIKE LOWER('%$name2_escaped%') LIMIT 1");

            if ($produk1_res && $produk2_res) {
                $produk1_row = mysqli_fetch_assoc($produk1_res);
                $produk2_row = mysqli_fetch_assoc($produk2_res);

                if ($produk1_row && $produk2_row) {
                    $code1 = $produk1_row['kode_produk'];
                    $code2 = $produk2_row['kode_produk'];
                    $pair_label = 'Jika membeli ' . $confidence_input1 . ' maka ada kemungkinan membeli ' . $confidence_input2;

                    mysqli_query($conn, "ALTER TABLE confidence MODIFY hasil DECIMAL(5,4)");
                    $insert_confidence = "INSERT INTO confidence (kondisi, hasil) VALUES ('$pair_label', '$confidence_result')";
                    if (mysqli_query($conn, $insert_confidence)) {
                        $_SESSION['active_form'] = 'form3';
                        $_SESSION['flash_message'] = 'Data berhasil disimpan.';
                        header('Location: index.php?menu=apriori');
                        exit;
                    } else {
                        echo 'Error: ' . mysqli_error($conn);
                    }
                } else {
                    $confidence_error = 'Satu atau lebih nama produk tidak ditemukan.';
                    $active_form = 'form3';
                }
            } else {
                $confidence_error = 'Gagal membaca data produk.';
                $active_form = 'form3';
            }
        }
    }

    // ================= DATA PRODUK =================
    if (isset($_POST['delete_produk_id'])) {
        $deleteId = (int)($_POST['delete_produk_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM data_produk WHERE id = $deleteId");
            compactTableIds($conn, 'data_produk');
            $_SESSION['flash_message'] = 'Data produk berhasil dihapus.';
            header('Location: index.php?menu=produk');
            exit;
        }
    }

    if (isset($_POST['tambah_produk'])) {
        $produk_kode = trim((string)($_POST['produk_kode'] ?? ''));
        $produk_nama = trim((string)($_POST['produk_nama'] ?? ''));

        if ($produk_kode === '' || $produk_nama === '') {
            $produk_error = 'Kode produk dan nama produk wajib diisi.';
            $active_form = 'formProduk';
        } else {
            $produk_kode_escaped = mysqli_real_escape_string($conn, $produk_kode);
            $produk_nama_escaped = mysqli_real_escape_string($conn, $produk_nama);

            $cek_duplikat_produk = mysqli_query($conn, "SELECT 1 FROM data_produk WHERE kode_produk = '$produk_kode_escaped' LIMIT 1");
            if ($cek_duplikat_produk && mysqli_num_rows($cek_duplikat_produk) > 0) {
                $_SESSION['active_form'] = 'formProduk';
                $_SESSION['flash_message'] = 'Kode produk sudah terdaftar.';
                header('Location: index.php?menu=produk');
                exit;
            }

            $query_tambah_produk = "INSERT INTO data_produk (kode_produk, nama_produk) VALUES ('$produk_kode_escaped', '$produk_nama_escaped')";
            if (mysqli_query($conn, $query_tambah_produk)) {
                $_SESSION['active_form'] = 'formProduk';
                $_SESSION['flash_message'] = 'Data produk berhasil ditambahkan.';
                header('Location: index.php?menu=produk');
                exit;
            } else {
                echo 'Error: ' . mysqli_error($conn);
            }
        }
    }

    // ================= DATA TRANSAKSI =================
    if (isset($_POST['delete_transaksi_id'])) {
        $deleteId = (int)($_POST['delete_transaksi_id'] ?? 0);
        if ($deleteId > 0) {
            mysqli_query($conn, "DELETE FROM transaksi WHERE id = $deleteId");
            compactTableIds($conn, 'transaksi');
            $_SESSION['flash_message'] = 'Data transaksi berhasil dihapus.';
            header('Location: index.php?menu=transaksi');
            exit;
        }
    }

    if (isset($_POST['tambah_transaksi'])) {
        $transaksi_produk_selected = (isset($_POST['transaksi_produk']) && is_array($_POST['transaksi_produk']))
            ? $_POST['transaksi_produk']
            : [];

        if (empty($transaksi_produk_selected)) {
            $transaksi_error = 'Pilih minimal satu produk.';
            $active_form = 'formTransaksi';
        } else {
            $kode_bersih = [];
            foreach ($transaksi_produk_selected as $kode) {
                $kode_bersih[] = mysqli_real_escape_string($conn, trim((string)$kode));
            }
            $produk_string = implode(', ', $kode_bersih);

            // Cek kode transaksi terakhir (T1, T2, T3, ...) lalu lanjutkan otomatis
            $kode_transaksi_baru = generateKodeTransaksi($conn);

            $query_tambah_transaksi = "INSERT INTO transaksi (kode, produk) VALUES ('$kode_transaksi_baru', '$produk_string')";
            if (mysqli_query($conn, $query_tambah_transaksi)) {
                $_SESSION['active_form'] = 'formTransaksi';
                $_SESSION['flash_message'] = 'Data transaksi berhasil ditambahkan dengan kode ' . $kode_transaksi_baru . '.';
                header('Location: index.php?menu=transaksi');
                exit;
            } else {
                echo 'Error: ' . mysqli_error($conn);
            }
        }
    }
}

// Kelas 'active' buat modal & tombol step, berdasarkan $active_form
$modal_form1 = ($active_form === 'form1') ? ' active' : '';
$modal_form2 = ($active_form === 'form2') ? ' active' : '';
$modal_form3 = ($active_form === 'form3') ? ' active' : '';
$modal_formProduk = ($active_form === 'formProduk') ? ' active' : '';
$modal_formTransaksi = ($active_form === 'formTransaksi') ? ' active' : '';

$step1_active = ($active_form === 'form1' || $active_form === '') ? ' active' : '';
$step2_active = ($active_form === 'form2') ? ' active' : '';
$step3_active = ($active_form === 'form3') ? ' active' : '';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perhitungan Apriori</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        html, body {
            height: 100%;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #F1F3F6;
            color: #1F2937;
            line-height: 1.5;
        }

        :root {
            --bg: #F1F3F6;
            --surface: #FFFFFF;
            --border: #E3E6EB;
            --border-strong: #D3D7DE;
            --text-primary: #1F2937;
            --text-secondary: #5B6472;
            --text-muted: #9AA1AC;
            --accent: #3D5A80;
            --accent-hover: #32496A;
            --accent-soft: #E8EEF4;
            --success: #2F7D5C;
            --success-soft: #E4F3EC;
            --danger: #B3413A;
            --danger-soft: #FBEAE8;
            --radius-lg: 14px;
            --radius-md: 10px;
            --radius-sm: 8px;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .kiri {
            width: 256px;
            flex-shrink: 0;
            background: var(--surface);
            border-right: 1px solid var(--border);
            padding: 28px 20px;
            display: flex;
            flex-direction: column;
            gap: 16px;
            position: relative;
        }

        .headKir span {
            font-weight: 700;
            font-size: 1.05rem;
            color: var(--text-primary);
            position: relative;
            padding-left: 16px;
        }
        .headKir span::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--accent);
        }
        .kiri hr {
            border: none;
            border-top: 1px solid var(--border);
        }
        .kiri ul {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 3px;
            flex: 1;
        }
        .kiri li {
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            font-size: .9rem;
            font-weight: 500;
            color: var(--text-secondary);
            cursor: pointer;
            border-left: 2px solid transparent;
            transition: all .15s ease;
        }
        .kiri li:hover {
            background: var(--accent-soft);
            color: var(--accent);
        }
        .kiri li.active {
            background: var(--accent-soft);
            color: var(--accent);
            border-left-color: var(--accent);
            font-weight: 600;
        }

        /* Logout di sidebar */
        .logout-item {
            margin-top: auto;
            border-top: 1px solid var(--border);
            padding-top: 12px;
        }
        .logout-item li {
            color: var(--danger);
            border-left-color: transparent;
            padding: 10px 14px;
            border-radius: var(--radius-sm);
            font-size: .9rem;
            font-weight: 500;
            cursor: pointer;
            transition: all .15s ease;
            list-style: none;
        }
        .logout-item li:hover {
            background: var(--danger-soft);
            color: var(--danger);
            border-left-color: var(--danger);
        }

        /* Main content */
        .kanan {
            flex: 1;
            min-width: 0;
            position: relative;
            padding: 32px 40px 56px;
        }
        .kanan > header {
            font-weight: 700;
            font-size: 1.3rem;
            color: var(--text-primary);
            padding-bottom: 16px;
            margin-bottom: 24px;
            padding-right: 170px;
            border-bottom: 1px solid var(--border);
        }
        .adminBarKanan {
            position: absolute;
            top: 32px;
            right: 40px;
            display: flex;
            align-items: center;
            gap: 10px;
            background: var(--surface);
            border: 1px solid var(--border);
            padding: 6px 16px 6px 6px;
            border-radius: 999px;
        }
        .adminBarKanan span:first-child {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--accent);
            color: #fff;
            font-weight: 700;
            font-size: .78rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .adminBarKanan span:last-child {
            font-size: .84rem;
            font-weight: 600;
            color: var(--text-secondary);
        }

        .containerKan {
            display: flex;
            flex-direction: column;
            gap: 22px;
        }

        /* Cards */
        .buttonArea,
        .tableArea {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 22px 26px;
            box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
        }

        .text span,
        .textt span {
            font-size: .74rem;
            font-weight: 600;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--text-muted);
            display: block;
            margin-bottom: 14px;
        }

        /* Buttons */
        .btn,
        .tabelbtn {
            position: relative;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            counter-reset: stage;
        }
        .btn::before,
        .tabelbtn::before {
            content: '';
            position: absolute;
            left: 18px;
            right: 18px;
            top: 50%;
            height: 1px;
            background: var(--border-strong);
            z-index: 0;
            pointer-events: none;
        }
        .btn button,
        .tabelbtn button {
            counter-increment: stage;
            position: relative;
            z-index: 1;
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: .84rem;
            color: var(--text-secondary);
            background: var(--surface);
            border: 1px solid var(--border-strong);
            padding: 9px 20px 9px 30px;
            border-radius: 999px;
            margin: 4px 12px 4px 0;
            cursor: pointer;
            transition: all .15s ease;
        }
        .btn button:last-child,
        .tabelbtn button:last-child {
            margin-right: 0;
        }
        .btn button::before,
        .tabelbtn button::before {
            content: counter(stage);
            position: absolute;
            left: 9px;
            top: 50%;
            transform: translateY(-50%);
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: var(--bg);
            color: var(--text-muted);
            font-family: 'IBM Plex Mono', monospace;
            font-size: .62rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .btn button:hover,
        .tabelbtn button:hover {
            border-color: var(--accent);
            color: var(--accent);
        }
        .btn button.active,
        .tabelbtn button.active {
            background: var(--accent);
            color: #fff;
            border-color: var(--accent);
        }
        .btn button.active::before,
        .tabelbtn button.active::before {
            background: rgba(255, 255, 255, 0.2);
            color: #fff;
        }

        /* Tables */
        .table {
            margin-top: 20px;
        }
        .table1,
        .table2,
        .table3 {
            display: none;
            overflow-x: auto;
        }
        .table1.active,
        .table2.active,
        .table3.active {
            display: block;
            animation: fadeIn .2s ease;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(3px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .titleT {
            font-weight: 700;
            font-size: .98rem;
            color: var(--text-primary);
            display: block;
            margin-bottom: 12px;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            overflow: hidden;
        }
        th {
            font-size: .7rem;
            font-weight: 600;
            letter-spacing: .06em;
            text-transform: uppercase;
            color: var(--text-muted);
            background: #FAFBFC;
            text-align: left;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
        }
        td {
            padding: 11px 16px;
            font-size: .87rem;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border);
        }
        td:not(.no-mono) {
            font-family: 'IBM Plex Mono', monospace;
        }
        tr:last-child td {
            border-bottom: none;
        }
        tr:hover td {
            background: #FAFBFC;
        }

        .btn-delete {
            padding: 4px 12px;
            border: none;
            border-radius: var(--radius-sm);
            font-size: .75rem;
            font-weight: 600;
            cursor: pointer;
            transition: background .15s ease;
            background: var(--danger-soft);
            color: var(--danger);
        }
        .btn-delete:hover {
            background: var(--danger);
            color: #fff;
        }

        .btn-tambah {
            padding: 9px 18px;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            font-size: .84rem;
            cursor: pointer;
            transition: background .15s ease;
        }
        .btn-tambah:hover {
            background: var(--accent-hover);
        }

        .btn-edit {
            padding: 4px 12px;
            border: 1px solid var(--border-strong);
            border-radius: var(--radius-sm);
            font-size: .75rem;
            font-weight: 600;
            cursor: pointer;
            background: var(--surface);
            color: var(--text-secondary);
            transition: all .15s ease;
        }
        .btn-edit:hover {
            border-color: var(--accent);
            color: var(--accent);
        }

        .produk-checklist {
            max-height: 190px;
            overflow-y: auto;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 10px 12px;
            background: #fcfcfd;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .produk-check-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: .86rem;
            color: var(--text-primary);
            cursor: pointer;
        }
        .produk-check-item input {
            width: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border);
        }
        .modal-title {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        .modal-close {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: #999;
            transition: color .2s;
            line-height: 1;
        }
        .modal-close:hover {
            color: #333;
        }

        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-size: .8rem;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: .9rem;
            transition: all .15s ease;
        }
        .form-group input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(61, 90, 128, 0.12);
        }

        @keyframes modalAppear {
            from {
                opacity: 0;
                transform: translate(-50%, -48%) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }

        /* Apriori Forms */
        .form1,
        .form2,
        .form3,
        .formProduk,
        .formTransaksi {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 30px;
            border-radius: 12px;
            z-index: 1000;
            width: 90%;
            max-width: 700px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            max-height: 90vh;
            overflow-y: auto;
        }
        .form1.active,
        .form2.active,
        .form3.active,
        .formProduk.active,
        .formTransaksi.active {
            display: block;
            animation: modalAppear .3s ease;
        }

        .form1 input,
        .form2 input,
        .form3 input,
        .formProduk input,
        .formTransaksi input,
        .form1 select,
        .form2 select,
        .form3 select,
        .formProduk select,
        .formTransaksi select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: .9rem;
            transition: all .15s ease;
        }
        .form1 input:focus,
        .form2 input:focus,
        .form3 input:focus,
        .formProduk input:focus,
        .formTransaksi input:focus,
        .form1 select:focus,
        .form2 select:focus,
        .form3 select:focus,
        .formProduk select:focus,
        .formTransaksi select:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(61, 90, 128, 0.12);
        }
        .form1 button[type="submit"],
        .form2 button[type="submit"],
        .form3 button[type="submit"],
        .formProduk button[type="submit"],
        .formTransaksi button[type="submit"] {
            padding: 10px 24px;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            cursor: pointer;
            transition: background .15s ease;
            margin-top: 8px;
        }
        .form1 button[type="submit"]:hover,
        .form2 button[type="submit"]:hover,
        .form3 button[type="submit"]:hover,
        .formProduk button[type="submit"]:hover,
        .formTransaksi button[type="submit"]:hover {
            background: var(--accent-hover);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 3px 11px;
            border-radius: 999px;
            font-family: 'Inter', sans-serif;
            font-size: .72rem;
            font-weight: 600;
        }
        .badge::before {
            content: '';
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: currentColor;
        }
        .badge-lolos {
            background: var(--success-soft);
            color: var(--success);
        }
        .badge-gugur {
            background: var(--danger-soft);
            color: var(--danger);
        }

        .flash-message {
            padding: 12px 16px;
            border-radius: var(--radius-sm);
            background: var(--success-soft);
            color: var(--success);
            font-weight: 500;
            margin-bottom: 16px;
            border-left: 3px solid var(--success);
        }

        .flash-message.error {
            background: var(--danger-soft);
            color: var(--danger);
            border-left-color: var(--danger);
        }

        @media (max-width: 860px) {
            .container {
                flex-direction: column;
            }
            .kiri {
                width: 100%;
                flex-direction: row;
                align-items: center;
                justify-content: space-between;
                padding: 14px 20px;
            }
            .kiri hr {
                display: none;
            }
            .kiri ul {
                flex-direction: row;
            }
            .logout-item {
                margin-top: 0;
                border-top: none;
                padding-top: 0;
            }
            .kanan {
                padding: 84px 20px 40px;
            }
            .kanan>header {
                padding-right: 0;
            }
            .adminBarKanan {
                top: 14px;
                right: 20px;
            }
            .btn::before,
            .tabelbtn::before {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">

        <div class="kiri">
            <div class="headKir">
                <span>Admin</span>
            </div>
            <hr>
            <ul>
                <li class="<?php echo $active_menu === 'apriori' ? 'active' : ''; ?>" onclick="window.location.href='?menu=apriori'">Data Apriori</li>
                <li class="<?php echo $active_menu === 'produk' ? 'active' : ''; ?>" onclick="window.location.href='?menu=produk'">Data Produk</li>
                <li class="<?php echo $active_menu === 'transaksi' ? 'active' : ''; ?>" onclick="window.location.href='?menu=transaksi'">Data Transaksi</li>
            </ul>
            <div class="logout-item">
                <li onclick="window.location.href='?logout=1'">🚪 Logout</li>
            </div>
        </div>

        <div class="kanan">
            <header>
                <?php
                if ($active_menu === 'apriori') echo 'PERHITUNGAN DATA APRIORI';
                elseif ($active_menu === 'produk') echo 'KELOLA DATA PRODUK';
                elseif ($active_menu === 'transaksi') echo 'KELOLA DATA TRANSAKSI';
                ?>
            </header>
            <div class="adminBarKanan">
                <span>A</span>
                <span>Admin</span>
            </div>

            <?php if ($saved_message): ?>
                <div class="flash-message"><?php echo htmlspecialchars($saved_message); ?></div>
            <?php endif; ?>

            <div class="containerKan">
                <?php if ($active_menu === 'apriori'): ?>
                    <!-- APRIORI -->
                    <div class="buttonArea">
                        <div class="text"><span>Hitung:</span></div>
                        <div class="btn">
                            <button type="button" class="sup1F<?php echo $step1_active; ?>">C1 & L1</button>
                            <button type="button" class="sup2F<?php echo $step2_active; ?>">C2 & L2</button>
                            <button type="button" class="ConF<?php echo $step3_active; ?>">Confidence</button>
                        </div>
                    </div>
                    <div class="tableArea">
                        <div class="textt"><span>Daftar Table:</span></div>
                        <div class="tabelbtn">
                            <button type="button" class="sup1 active">C1 & L1</button>
                            <button type="button" class="sup2">C2 & L2</button>
                            <button type="button" class="Con">Confidence</button>
                        </div>
                        <div class="table">
                            <div class="table1 active">
                                <span class="titleT">C1 & L1</span>
                                <table>
                                    <tr>
                                        <th>Kode Produk</th>
                                        <th>Jumlah Kemunculan</th>
                                        <th>Nilai Support</th>
                                        <th>Status</th>
                                      
                                    </tr>
                                    <?php
                                    $queryt1 = "SELECT * FROM support1";
                                    $resultt1 = mysqli_query($conn, $queryt1);
                                    while ($rowt1 = mysqli_fetch_assoc($resultt1)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($rowt1['kode_produk']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt1['jumlah_muncul']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt1['nilai']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt1['status']) . '</td>';
                                        
                                        echo '</tr>';
                                    }
                                    ?>
                                </table>
                            </div>

                            <div class="table2">
                                <span class="titleT">C2 & L2</span>
                                <table>
                                    <tr>
                                        <th>Kombinasi Itemset</th>
                                        <th>Jumlah Kemunculan Bersama</th>
                                        <th>Nilai Support</th>
                                       
                                    </tr>
                                    <?php
                                    $queryt2 = "SELECT * FROM support2";
                                    $resultt2 = mysqli_query($conn, $queryt2);
                                    while ($rowt2 = mysqli_fetch_assoc($resultt2)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($rowt2['kode_produk']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt2['muncul_bersama']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt2['nilai']) . '</td>';
                                       
                                        echo '</tr>';
                                    }
                                    ?>
                                </table>
                            </div>

                            <div class="table3">
                                <span class="titleT">Confidence</span>
                                <table>
                                    <tr>
                                        <th>Kondisi</th>
                                        <th>Hasil</th>
                                       
                                    </tr>
                                    <?php
                                    $queryt3 = "SELECT * FROM confidence";
                                    $resultt3 = mysqli_query($conn, $queryt3);
                                    while ($rowt3 = mysqli_fetch_assoc($resultt3)) {
                                        echo '<tr>';
                                        echo '<td>' . htmlspecialchars($rowt3['kondisi']) . '</td>';
                                        echo '<td>' . htmlspecialchars($rowt3['hasil']) . '</td>';
                                       
                                        echo '</tr>';
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                <?php elseif ($active_menu === 'produk'): ?>
                    <!-- DATA PRODUK -->
                    <div class="buttonArea">
                        <div class="text"><span>Aksi:</span></div>
                        <button type="button" class="btn-tambah tambahProdukBtn">+ Tambah Data Produk</button>
                    </div>
                    <div class="tableArea">
                        <div class="textt"><span>Daftar Produk:</span></div>
                        <div class="table">
                            <div class="table1 active">
                                <span class="titleT">Data Produk</span>
                                <table>
                                    <tr>
                                        <th>Kode Produk</th>
                                        <th class="no-mono">Nama Produk</th>
                                       
                                    </tr>
                                    <?php
                                    $query_list_produk = "SELECT * FROM data_produk";
                                    $result_list_produk = mysqli_query($conn, $query_list_produk);
                                    if ($result_list_produk && mysqli_num_rows($result_list_produk) > 0) {
                                        while ($row_list_produk = mysqli_fetch_assoc($result_list_produk)) {
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row_list_produk['kode_produk']) . '</td>';
                                            echo '<td class="no-mono">' . htmlspecialchars($row_list_produk['nama_produk']) . '</td>';
                                           
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="3" class="no-mono">Belum ada data produk.</td></tr>';
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>

                <?php elseif ($active_menu === 'transaksi'): ?>
                    <!-- DATA TRANSAKSI -->
                    <div class="buttonArea">
                        <div class="text"><span>Aksi:</span></div>
                        <button type="button" class="btn-tambah tambahTransaksiBtn">+ Tambah Data Transaksi</button>
                    </div>
                    <div class="tableArea">
                        <div class="textt"><span>Daftar Transaksi:</span></div>
                        <div class="table">
                            <div class="table1 active">
                                <span class="titleT">Data Transaksi</span>
                                <table>
                                    <tr>
                                        <th>ID</th>
                                        <th class="no-mono">Produk</th>
                                       
                                    </tr>
                                    <?php
                                    $query_list_transaksi = "SELECT * FROM transaksi";
                                    $result_list_transaksi = mysqli_query($conn, $query_list_transaksi);
                                    if ($result_list_transaksi && mysqli_num_rows($result_list_transaksi) > 0) {
                                        while ($row_list_transaksi = mysqli_fetch_assoc($result_list_transaksi)) {
                                            echo '<tr>';
                                            echo '<td>' . htmlspecialchars($row_list_transaksi['kode']) . '</td>';
                                            echo '<td class="no-mono">' . htmlspecialchars($row_list_transaksi['produk']) . '</td>';
                                           
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="3" class="no-mono">Belum ada data transaksi.</td></tr>';
                                    }
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- APRIORI MODALS -->
        <div class="form1<?php echo $modal_form1; ?>">
            <div class="modal-header">
                <span class="modal-title">Hitung C1 & L1</span>
                <button class="modal-close" onclick="this.closest('.form1').classList.remove('active')">&times;</button>
            </div>
            <form action="?menu=apriori" method="post">
                <div class="form-group">
                    <label>Kode Produk</label>
                    <select name="kode_produk" onchange="this.form.submit()">
                        <option value="">-- Pilih Produk --</option>
                        <?php
                        $query_produk = "SELECT * FROM data_produk";
                        $result_produk = mysqli_query($conn, $query_produk);
                        while ($row_produk = mysqli_fetch_assoc($result_produk)) {
                            echo '<option value="' . htmlspecialchars($row_produk['kode_produk']) . '">' . htmlspecialchars($row_produk['nama_produk']) . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jumlah Kemunculan</label>
                    <input type="text" name="jumlah_kemunculan" readonly value="<?php echo isset($jumlah_kemunculan) ? htmlspecialchars($jumlah_kemunculan) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Nilai Support</label>
                    <input type="text" name="nilai_support1" readonly value="<?php echo isset($nilai_support1) ? htmlspecialchars($nilai_support1) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <input type="text" name="status" readonly value="<?php echo isset($status) ? htmlspecialchars($status) : ''; ?>">
                </div>
                <button type="submit" name="S1">Simpan</button>
            </form>
        </div>

        <div class="form2<?php echo $modal_form2; ?>">
            <div class="modal-header">
                <span class="modal-title">Hitung C2 & L2</span>
                <button class="modal-close" onclick="this.closest('.form2').classList.remove('active')">&times;</button>
            </div>
            <form action="?menu=apriori" method="post">
                <div class="form-group">
                    <label>Nama Produk 1, Nama Produk 2</label>
                    <input type="text" name="cari_kode" placeholder="Contoh: Scarlett Whitening, Avoskin" value="<?php echo isset($cari_kode) ? htmlspecialchars($cari_kode) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Pasangan Produk</label>
                    <input type="text" name="pair_result" readonly value="<?php echo isset($pair_result) ? htmlspecialchars($pair_result) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Jumlah Kemunculan Bersama</label>
                    <input type="text" name="jumlah_kemunculan2" readonly value="<?php echo isset($jumlah_kemunculan2) ? htmlspecialchars($jumlah_kemunculan2) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Nilai Support</label>
                    <input type="text" name="Nilai_support2" readonly value="<?php echo isset($nilai_support2) ? htmlspecialchars($nilai_support2) : ''; ?>">
                </div>
                <button type="submit" name="cari_hitung1">Cari & Hitung</button>
                <button type="submit" name="S2">Simpan</button>
            </form>
        </div>

        <div class="form3<?php echo $modal_form3; ?>">
            <div class="modal-header">
                <span class="modal-title">Confidence</span>
                <button class="modal-close" onclick="this.closest('.form3').classList.remove('active')">&times;</button>
            </div>
            <form action="?menu=apriori" method="post">
                <div class="form-group">
                    <label>Nama Produk 1</label>
                    <input type="text" name="confidence_input1" placeholder="Jika Membeli..." value="<?php echo isset($confidence_input1) ? htmlspecialchars($confidence_input1) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Nama Produk 2</label>
                    <input type="text" name="confidence_input2" placeholder="Maka Akan Membeli..." value="<?php echo isset($confidence_input2) ? htmlspecialchars($confidence_input2) : ''; ?>">
                </div>
                <div class="form-group">
                    <label>Hasil</label>
                    <input type="text" name="confidence_result" readonly value="<?php echo isset($confidence_result) ? htmlspecialchars($confidence_result) : ''; ?>">
                </div>
                <button type="submit" name="cari_hitung2">Cari & Hitung</button>
                <button type="submit" name="simpan2">Simpan</button>
            </form>
        </div>

        <!-- DATA PRODUK MODAL -->
        <div class="formProduk<?php echo $modal_formProduk; ?>">
            <div class="modal-header">
                <span class="modal-title">Tambah Data Produk</span>
                <button class="modal-close" onclick="this.closest('.formProduk').classList.remove('active')">&times;</button>
            </div>
            <?php if ($produk_error): ?>
                <div class="flash-message error"><?php echo htmlspecialchars($produk_error); ?></div>
            <?php endif; ?>
            <form action="?menu=produk" method="post">
                <div class="form-group">
                    <label>Kode Produk</label>
                    <input type="text" name="produk_kode" placeholder="Contoh: P001" value="<?php echo htmlspecialchars($produk_kode); ?>">
                </div>
                <div class="form-group">
                    <label>Nama Produk</label>
                    <input type="text" name="produk_nama" placeholder="Contoh: Scarlett Whitening" value="<?php echo htmlspecialchars($produk_nama); ?>">
                </div>
                <button type="submit" name="tambah_produk">Simpan</button>
            </form>
        </div>

        <!-- DATA TRANSAKSI MODAL -->
        <div class="formTransaksi<?php echo $modal_formTransaksi; ?>">
            <div class="modal-header">
                <span class="modal-title">Tambah Data Transaksi</span>
                <button class="modal-close" onclick="this.closest('.formTransaksi').classList.remove('active')">&times;</button>
            </div>
            <?php if ($transaksi_error): ?>
                <div class="flash-message error"><?php echo htmlspecialchars($transaksi_error); ?></div>
            <?php endif; ?>
            <form action="?menu=transaksi" method="post">
                <div class="form-group">
                    <label>Pilih Produk (satu transaksi bisa berisi lebih dari satu produk)</label>
                    <div class="produk-checklist">
                        <?php
                        $query_produk_checklist = "SELECT * FROM data_produk ORDER BY nama_produk ASC";
                        $result_produk_checklist = mysqli_query($conn, $query_produk_checklist);
                        if ($result_produk_checklist && mysqli_num_rows($result_produk_checklist) > 0) {
                            while ($row_checklist = mysqli_fetch_assoc($result_produk_checklist)) {
                                $kode_cl = htmlspecialchars($row_checklist['kode_produk']);
                                $nama_cl = htmlspecialchars($row_checklist['nama_produk']);
                                $checked_cl = in_array($row_checklist['kode_produk'], $transaksi_produk_selected, true) ? ' checked' : '';
                                echo '<label class="produk-check-item">';
                                echo '<input type="checkbox" name="transaksi_produk[]" value="' . $kode_cl . '"' . $checked_cl . '>';
                                echo $nama_cl . ' (' . $kode_cl . ')';
                                echo '</label>';
                            }
                        } else {
                            echo '<span style="font-size:.85rem;color:var(--text-muted);">Belum ada data produk. Tambahkan produk terlebih dahulu di menu Data Produk.</span>';
                        }
                        ?>
                    </div>
                </div>
                <button type="submit" name="tambah_transaksi">Simpan</button>
            </form>
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // ===== APRIORI TABLES =====
            const table1 = document.querySelector('.table1');
            const table2 = document.querySelector('.table2');
            const table3 = document.querySelector('.table3');
            const btn1 = document.querySelector('.sup1');
            const btn2 = document.querySelector('.sup2');
            const btn3 = document.querySelector('.Con');

            function showTable(tableToShow) {
                if (table1) table1.classList.remove('active');
                if (table2) table2.classList.remove('active');
                if (table3) table3.classList.remove('active');
                if (btn1) btn1.classList.remove('active');
                if (btn2) btn2.classList.remove('active');
                if (btn3) btn3.classList.remove('active');

                if (tableToShow === 'table1') {
                    if (table1) table1.classList.add('active');
                    if (btn1) btn1.classList.add('active');
                } else if (tableToShow === 'table2') {
                    if (table2) table2.classList.add('active');
                    if (btn2) btn2.classList.add('active');
                } else if (tableToShow === 'table3') {
                    if (table3) table3.classList.add('active');
                    if (btn3) btn3.classList.add('active');
                }
            }

            if (btn1) btn1.addEventListener('click', () => showTable('table1'));
            if (btn2) btn2.addEventListener('click', () => showTable('table2'));
            if (btn3) btn3.addEventListener('click', () => showTable('table3'));

            // ===== APRIORI FORMS =====
            const form1 = document.querySelector('.form1');
            const form2 = document.querySelector('.form2');
            const form3 = document.querySelector('.form3');
            const sup1F = document.querySelector('.sup1F');
            const sup2F = document.querySelector('.sup2F');
            const ConF = document.querySelector('.ConF');

            function showForm(formToShow) {
                if (form1) form1.classList.remove('active');
                if (form2) form2.classList.remove('active');
                if (form3) form3.classList.remove('active');
                if (sup1F) sup1F.classList.remove('active');
                if (sup2F) sup2F.classList.remove('active');
                if (ConF) ConF.classList.remove('active');

                if (formToShow === 'form1') {
                    if (form1) form1.classList.add('active');
                    if (sup1F) sup1F.classList.add('active');
                } else if (formToShow === 'form2') {
                    if (form2) form2.classList.add('active');
                    if (sup2F) sup2F.classList.add('active');
                } else if (formToShow === 'form3') {
                    if (form3) form3.classList.add('active');
                    if (ConF) ConF.classList.add('active');
                }
            }

            if (sup1F) sup1F.addEventListener('click', () => showForm('form1'));
            if (sup2F) sup2F.addEventListener('click', () => showForm('form2'));
            if (ConF) ConF.addEventListener('click', () => showForm('form3'));

            // ===== DATA PRODUK MODAL =====
            const tambahProdukBtn = document.querySelector('.tambahProdukBtn');
            const formProduk = document.querySelector('.formProduk');
            
            if (tambahProdukBtn) {
                tambahProdukBtn.addEventListener('click', function() {
                    if (formProduk) formProduk.classList.add('active');
                });
            }

            // ===== DATA TRANSAKSI MODAL =====
            const tambahTransaksiBtn = document.querySelector('.tambahTransaksiBtn');
            const formTransaksi = document.querySelector('.formTransaksi');

            if (tambahTransaksiBtn) {
                tambahTransaksiBtn.addEventListener('click', function() {
                    if (formTransaksi) formTransaksi.classList.add('active');
                });
            }

            // ===== TUTUP MODAL KETIKA KLIK DI LUAR =====
            const allModals = document.querySelectorAll('.form1, .form2, .form3, .formProduk, .formTransaksi');
            allModals.forEach(function(modal) {
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        modal.classList.remove('active');
                    }
                });
            });
        });
    </script>
</body>
</html>